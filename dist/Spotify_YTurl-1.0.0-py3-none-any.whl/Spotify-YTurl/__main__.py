zlYJdxQsCTSRaELpJCjuGHylCAwczcDC="""\x22\x6e\x6f\x74\x68\x69\x6e\x67\x22"""
exec(zlYJdxQsCTSRaELpJCjuGHylCAwczcDC)